<html>
<form action="upload_assignment.php" method="post" style="position:absolute;left:260px;top:100px;font-size:80px;" enctype="multipart/form-data">
<b>Select Assignment PDF</b><br><br><input style="width:900px;height:90px;" type="file" name="assignment"/><br><br>
<b>Select Lab       </b><select name="lab" style="width:900px;height:90px;"><option value="dbms">DBMS LAB</option><option value="ada">ADA LAB</option><option value="java">JAVA/PHP LAB</option><option value="se">SE LAB</option></select>
<br><br>
<input type="submit" value="Upload"/>
</form>
</html>