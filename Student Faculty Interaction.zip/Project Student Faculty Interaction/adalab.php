<!DOCTYPE html>
<html>
	<head>
		<title>ADA Lab</title>
		<link rel="stylesheet" type="text/css" href="home1.css">
		<link rel="stylesheet" type="text/css" href="profile.css">
		<style type="text/css">
			
			body{
	background-image:url(img/105.jpg);
	background-repeat:no-repeat;
	background-size:cover;
	opacity: 0.9;
	background-attachment: fixed;
}

			a{
				text-decoration:none;
				font-size:150px;
				font-family:"comic sans ms";
				font-weight:bold;
				color:black;
			}
			button{
				width:750px;	
				height:600px;
				opacity:0.8;
				
			}
			
			
		</style>
	</head>
<body>

<div class="slider">	
<button style="width:370px; height:120px; background-color: white; color: black; font-size:60px; border: none; font-family:'georgian' left:4800px;">
   <a href="login.php" style="font-size:60px; border: none; font-family:'georgian'; ">Logout</a></button>
<div class="dropdown"> 
  <button class="dropbtn">MENU</button>
  <div class="dropdown-content">
 <a href="home.php">Home</a>
    <a href="login.php">Login</a>
    <a href="student_register.php">Register</a>
	
	<a href="lab.php">Labs</a>
  </div>
 </div> 
  <h2 style="text-align: center; color:white; font-size: 200px;position:fixed;top:100px;left:70px;" >ADA Lab Assignments </h2>

 <div style="width:70%;height:1900px;position:absolute;top:700px;left:700px;background-color:	#F0E68C;z-index:1000;opacity:0.8;">
</div>

</body>
</html>	
	