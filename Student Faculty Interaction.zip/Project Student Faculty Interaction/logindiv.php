<!Doctype html>
<html>
<body>
<form action="islogin.php" method="POST">
<table>
<tr>
<td>Username</td></tr>
<tr><td><input type="text" name="username" style="width:900px;height:90px;"></td></tr>
</tr><tr></tr><tr><td></td></tr><td></td></tr>
<td>Password</td></tr>
<tr><td><input type="password" name="password" style="width:900px;height:90px;"></td></tr>
</table>
<br>
<input type="submit" value="Login" style="text-family:calibri;font-size:70px;text-align:center;padding:20px 40px; margin:8px 10px;position:absolute;left:0px;"/>
</form>
</body>
</html>