<html>
<head>
<title> About us </title>
<link rel="stylesheet" type="text/css" href="home1.css">
<link rel="stylesheet" type="text/css" href="aboutus.css">
</head>
<body>
<div class="slider">	

<div class="dropdown"> 
  <button class="dropbtn">MENU</button>
  <div class="dropdown-content">
 <a href="home.php">Home</a>
    <a href="login.php">Login</a>
    <a href="student_register.php">Register</a>
  </div>
 </div> 
 <br><br>
 <h1 style="text-align: center; color:white; font-size: 200px;" > Development Team</h1>
 
	
	<div class="yashi">
	<h1 style="text-align:center;text-family:calibri;font-size:100px;color:white;padding:20px;">Yashasvini Rathore<br/> 161112014</h1>
	<img src="yashi1.jpg" style="align:center; width:1200px; height:1200px;" />
	</div>
	<div class="mansij">
	<h1 style="text-align:center;text-family:calibri;font-size:100px;color:white;padding:20px;">Mansi Jain <br/> 161112103</h1>
	<img src="mj1.jpg" style="align:center; width:1200px; height:1200px;" />
	</div>
	<div class="mansio">
	<h1 style="text-align:center;text-family:calibri;font-size:100px;color:white;padding:20px;">Mansi Oberai <br/> 161112105</h1>
	<img src="mo1.jpg" style="align:center; width:1200px; height:1200px;" />
	</div>
</body>
</html>	