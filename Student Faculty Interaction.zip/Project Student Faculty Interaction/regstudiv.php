<!DOCTYPE HTML>
<html>
<body>
<form action="studententryindb.php" method="POST" style="padding:20px;">
<table>
<tr>
<td>Full Name</td>
<td> <input type="text" name="Student_name" style="width:900px;height:90px;"/></td><br>
</tr>
<tr>
<td>Scholar number</td><td><input type="int" name="Sch_no" style="width:900px;height:90px;"/></td>
</tr>
<tr>
<td>Semester</td><td><input type="text" name="Semester" style="width:900px;height:90px;"/></td>
</tr>
<tr>
<td>Date of Birth</td><td><input type="text" name="DOB" placeholder="yyyy/mm/dd" style="width:900px;height:90px;"/></td>
</tr>
<tr>
<td>Department Code </td><td><input type="text" name="Dept_code" style="width:900px;height:90px;"/></td>
</tr>
<tr>
<td>E-mail ID</td><td><input type="email" name="Email_ID" style="width:900px;height:90px;"/></td>
</tr>
<tr>
<td>Address</td><td><input type="text" name="Address" style="width:900px;height:90px;"/></td>
</tr>
<tr>
<td>Contact Number</td><td><input type="text" name="Phone_no" style="width:900px;height:90px;"/></td>
</tr>
<tr>
<td>Username</td><td><input type="text" name="Username" style="width:900px;height:90px;"/></td>
</tr>
<tr>
<td>Password</td><td><input type="password" name="Password" style="width:900px;height:90px;"/></td>
</tr>
</table>
<br><br>
<input type="Submit" value="Register" style="text-family:calibri;font-size:70px;text-align:center;padding:20px 40px; margin:8px 10px;position:absolute;left:0px;"/>
<input type="Reset" style="text-family:calibri;font-size:70px;text-align:center;padding:20px 40px; margin:8px 10px;position:absolute;left:400px;"/>

</form>
</body>
</html>