<!DOCTYPE html>
<html>
	<head>
		<title>Labs</title>
		<link rel="stylesheet" type="text/css" href="home1.css">
		<link rel="stylesheet" type="text/css" href="profile.css">
		<style type="text/css">
			
			body{
	background-image:url(img/101.jpg);
	background-repeat:no-repeat;
	background-size:cover;
	opacity: 0.9;
	background-attachment: fixed;
}

			a{
				text-decoration:none;
				font-size:150px;
				font-family:"comic sans ms";
				font-weight:bold;
				color:black;
			}
			button{
				width:750px;	
				height:600px;
				opacity:0.8;
				
			}
			
			
		</style>
	</head>
<body>

<div class="slider">	
<button style="width:370px; height:120px; background-color: white; color: black; font-size:60px; border: none; font-family:'georgian' left:4800px;">
   <a href="login.php" style="font-size:60px; border: none; font-family:'georgian'; ">Logout</a></button>
<div class="dropdown"> 
  <button class="dropbtn">MENU</button>
  <div class="dropdown-content">
 <a href="home.php">Home</a>
    <a href="login.php">Login</a>
    <a href="student_register.php">Register</a>
	
  </div>
 </div> 
 
 <h1 style="text-align: center; color:white; font-size: 200px;" >Lab Assignments </h1>
 <div id="d1" style="position:absolute;z-index:100;color:white;width:100%,height:100%;top:1000px;left:900px;">
 <button><a href="sedownload.php?file=dbms"><h6> DBMS LAB</h6></a>
 </button>
 
 <div id="d1" style="position:absolute;z-index:100;color:white;width:100%,height:100%;top:0px;left:900px;">
 <button><a href="sedownload.php?file=java"><h6> JAVA/PHP</h6></a>
 </button>
 </div>
 <div id="d1" style="position:absolute;z-index:100;color:white;width:100%,height:100%;top:0px;left:1800px;">
 <button><a href="sedownload.php?file=se"><h6> SE LAB</h6></a>
 </button>
 </div>
 <div id="d1" style="position:absolute;z-index:100;color:white;width:100%,height:100%;top:0px;left:2700px;">
 <button><a href="sedownload.php?file=ada"><h6> ADA LAB</h6></a>
 </button>
 

 
</body>
</html>	
	