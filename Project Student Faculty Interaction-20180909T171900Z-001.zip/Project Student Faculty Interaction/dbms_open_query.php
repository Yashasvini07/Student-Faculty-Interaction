<html>
<form action="dbms_submit_open_query.php" method="post" style="position:absolute;left:260px;top:100px;">
<input type="textarea" name="question" placeholder="Write your query here."/><br><br>
<input type="text" name="Sch_no" placeholder="Scholar Number"/><br><br><br>
<input type="submit" value="ASK"/>
</form>
</html>