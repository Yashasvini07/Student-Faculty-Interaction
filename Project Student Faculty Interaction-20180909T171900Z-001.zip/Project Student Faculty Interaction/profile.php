<!DOCTYPE html>
<html>
	<head>
		<title>Profile</title>
		<link rel="stylesheet" type="text/css" href="home1.css">
		<link rel="stylesheet" type="text/css" href="profile.css">
		<style type="text/css">
body{
	background-image:url(img/100.jpg);
	background-repeat:no-repeat;
	background-size:cover;
	opacity: 0.8;
	background-attachment: fixed;
}


			a{
				text-decoration:none;
				font-size:150px;
				font-family:"comic sans ms";
				font-weight:bold;
				color:black;
			}
			button{
				width:750px;	
				height:600px;
				opacity:0.8;
				
			}
			
			
		</style>
	</head>
<body>

<div class="slider">	
<button style="width:370px; height:120px; background-color: white; color: black; font-size:60px; border: none; font-family:'georgian' left:4800px;">
   <a href="login.php" style="font-size:60px; border: none; font-family:'georgian'; ">Logout</a></button>
<div class="dropdown"> 
  <button class="dropbtn">MENU</button>
  <div class="dropdown-content">
 <a href="home.php">Home</a>
    <a href="login.php">Login</a>
    <a href="student_register.php">Register</a>
  </div>
 </div> 
 <h1 style="text-align: center; color:white; font-size: 200px;" > Welcome to your Profile Page! </h1>
  
 <div id="d1" style="position:absolute; z-index:100; color:white; width:100%,height:100%;top:700px;left:400px;">

 <button> <a href="student_query.php"><h6>TOC</h6></a>
 </button>
 </div>
 <div id="d1" style="position:absolute;z-index:100;color:white;width:100%,height:100%;top:700px;left:1200px;">
 <button><a href="ada_query.php"><h6> ADA</h6></a>
 </button>
 </div>
 <div id="d1" style="position:absolute;z-index:100;color:white;width:100%,height:100%;top:700px;left:2000px;">
 <button><a href="dbms_query.php"><h6> DBMS</h6></a>
 </button>
 </div>
 <div id="d1" style="position:absolute;z-index:100;color:white;width:100%,height:100%;top:700px;left:2800px;">
 <button><a href="ca_query.php"><h6> CA</h6></a>
 </button>
 </div>
 <div id="d1" style="position:absolute;z-index:100;color:white;width:100%,height:100%;top:700px;left:3600px;">
 <button><a href="se_query.php"><h6> SE</h6></a>
 </button>
 </div>
 <div id="d1" style="position:absolute;z-index:100;color:white;width:100%,height:100%;top:700px;left:4400px;">
 <button><a href="pqt_query.php"><h6> PQT</h6></a>
 </button>
 </div>
 <div id="d2" style="position:absolute;z-index:100;color:white;width:1200px,height:300px;top:1400px;left:2200px;">
 <button style="width:1000px;"><a href="lab.php"><h6> Lab Assignments</h6></a>
 </button>
 <!--</div>
 <div id="d1" style="position:absolute;z-index:100;color:white;width:100%,height:100%;top:1400px;left:2000px;">
 <button><a href="javaphp.php"><h6> JAVA/PHP</h6></a>
 </button>
 </div>
 <div id="d1" style="position:absolute;z-index:100;color:white;width:100%,height:100%;top:1400px;left:2800px;">
 <button><a href="selab.php"><h6> SE LAB</h6></a>
 </button>
 </div>
 <div id="d1" style="position:absolute;z-index:100;color:white;width:100%,height:100%;top:1400px;left:3600px;">
 <button><a href="adalab.php"><h6> ADA LAB</h6></a>
 </button>
 </div>

 -->
</body>
</html>	
	